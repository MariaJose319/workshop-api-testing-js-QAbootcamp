const { JsonReport } = require('./report');

exports.JsonReport = JsonReport;
